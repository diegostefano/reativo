/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef ISR_H
#define ISR_H
    
#include <project.h>

CY_ISR_PROTO(timer_motores_isr_handler);
CY_ISR_PROTO(timer_cinematico_isr_handler);

#endif

/* [] END OF FILE */
